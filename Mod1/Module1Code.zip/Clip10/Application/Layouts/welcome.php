<html>
<body>
<div id="content">
    <?php echo 'Hello ' . ucfirst($this->user['first_name'] . ', welcome back!')?>
    <br />
    <a href="index.php?action=logout">Logout</a>
</div>
</body>
</html>