<?php
/**
 * System configuration
 */
return [
    'db' => [
        'dsn' => 'mysql:host=127.0.0.1;dbname=site',
        'user' => 'admin',
        'pass' => 'test',
    ],
];