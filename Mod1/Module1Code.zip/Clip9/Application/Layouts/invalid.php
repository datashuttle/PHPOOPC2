<html>
<body>
<div id="content">
    <?php echo 'Invalid submit, you\'re out of here.'?>
</div>
</body>
</html>