<html>
<body>
<div id="content">
    <?php echo 'Hello, welcome back'?>
    <br />
    <a href="index.php?action=logout">Logout</a>
</div>
</body>
</html>