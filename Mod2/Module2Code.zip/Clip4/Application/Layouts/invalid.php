<html>
<body>
<div id="content">
    <?php echo 'Invalid credentials, you\'re out of here.'?>
</div>
</body>
</html>